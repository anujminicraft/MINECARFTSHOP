window.onload = function() {
    const loader = document.getElementById('loader');

    loader.style.display = "none";
    console.log("loade done!");
}